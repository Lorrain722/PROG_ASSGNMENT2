package com.mycompany.rescuecase;

public class InjuredAnimalRescue extends RescueCase {

    private String injuredDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(
            String caseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int rescueDays,
            double dailyCareCost,
            String injuredDescription,
            double veterinaryTreatmentCost,
            boolean surgeryRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        this.injuredDescription = injuredDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    public String getInjuredDescription() {
        return injuredDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }

    @Override
    public double calculateTotalCost() {

        double total = calculateBasicCareCost()
                + veterinaryTreatmentCost;

        if (surgeryRequired) {
            total += 5000;
        }

        return total;
    }

    @Override
    public String determinePriority() {

        if (surgeryRequired) {
            return "HIGH";
        }

        if (veterinaryTreatmentCost > 0) {
            return "MEDIUM";
        }

        return "LOW";
    }

    @Override
    public String displaySpecificInformation() {

        return "Injured Description: " + injuredDescription +
                "\nVeterinary Treatment Cost: R" +
                String.format("%.2f", veterinaryTreatmentCost) +
                "\nSurgery Required: " +
                (surgeryRequired ? "Yes" : "No");
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }
}