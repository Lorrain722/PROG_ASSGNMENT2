package com.mycompany.rescuecase;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RescueCaseTest {

    @Test
    public void testInjuredRescueCost() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "RC001", "Leo", "Lion", "Kruger", "John",
                5, 200, "Broken leg", 3000, true);

        assertEquals(9000, rescue.calculateTotalCost(), 0.01);
    }

    @Test
    public void testOrphanedRescueCost() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "RC002", "Coco", "Monkey", "Mpumalanga", "Sarah",
                5, 150, 3, 1000, true);

        assertEquals(4250, rescue.calculateTotalCost(), 0.01);
    }

    @Test
    public void testEndangeredRescueCost() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "RC003", "Ella", "Rhino", "Limpopo", "David",
                5, 300, "Critically Endangered", 2000, true);

        assertEquals(11500, rescue.calculateTotalCost(), 0.01);
    }

    @Test
    public void testRescuePriority() {

        InjuredAnimalRescue injured = new InjuredAnimalRescue(
                "RC004", "Max", "Lion", "Kruger", "John",
                3, 200, "Severe injury", 2000, true);

        OrphanedAnimalRescue orphaned = new OrphanedAnimalRescue(
                "RC005", "Mia", "Elephant", "Limpopo", "Sarah",
                3, 150, 2, 500, true);

        EndangeredSpeciesRescue endangered = new EndangeredSpeciesRescue(
                "RC006", "Rex", "Rhino", "Mpumalanga", "David",
                3, 300, "Critically Endangered", 1000, true);

        assertEquals("HIGH", injured.determinePriority());
        assertEquals("HIGH", orphaned.determinePriority());
        assertEquals("HIGH", endangered.determinePriority());
    }

    @Test
    public void testSearchExistingRescueCase() {

        RescueSystem system = new RescueSystem();

        RescueCase rescue = new InjuredAnimalRescue(
                "RC007", "Leo", "Lion", "Kruger", "John",
                2, 200, "Broken leg", 1000, false);

        system.addRescueCase(rescue);

        RescueCase found = system.searchRescueCase("RC007");

        assertNotNull(found);
        assertEquals("RC007", found.getCaseId());
    }

    @Test
    public void testDuplicateRescueCaseIDPrevented() {

        RescueSystem system = new RescueSystem();

        RescueCase first = new InjuredAnimalRescue(
                "RC008", "A", "Lion", "Kruger", "John",
                2, 200, "Injury", 1000, false);

        RescueCase duplicate = new OrphanedAnimalRescue(
                "RC008", "B", "Monkey", "Mpumalanga", "Sarah",
                2, 150, 3, 500, false);

        assertTrue(system.addRescueCase(first));
        assertFalse(system.addRescueCase(duplicate));
        assertEquals(1, system.getTotalCases());
    }

    @Test
    public void testStartAndCompleteRescue() {

        RescueCase rescue = new InjuredAnimalRescue(
                "RC009", "Leo", "Lion", "Kruger", "John",
                2, 200, "Injury", 1000, false);

        rescue.startRescue();

        assertEquals("In Progress",
                rescue.getCurrentRescueStatus());

        rescue.completeRescue();

        assertEquals("Completed",
                rescue.getCurrentRescueStatus());
    }
}
