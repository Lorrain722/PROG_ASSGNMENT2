package com.mycompany.rescuecase;

public class OrphanedAnimalRescue extends RescueCase {

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(
            String caseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int rescueDays,
            double dailyCareCost,
            int estimatedAgeMonths,
            double feedingCost,
            boolean fosterCareRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }

    @Override
    public double calculateTotalCost() {

        double total = calculateBasicCareCost()
                + feedingCost;

        if (fosterCareRequired) {
            total += 2500;
        }

        return total;
    }

    @Override
    public String determinePriority() {

        if (fosterCareRequired) {
            return "HIGH";
        }

        if (feedingCost > 0) {
            return "MEDIUM";
        }

        return "LOW";
    }

    @Override
    public String displaySpecificInformation() {

        return "Estimated Age: " + estimatedAgeMonths + " months" +
                "\nFeeding Cost: R" +
                String.format("%.2f", feedingCost) +
                "\nFoster Care Required: " +
                (fosterCareRequired ? "Yes" : "No");
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }
}