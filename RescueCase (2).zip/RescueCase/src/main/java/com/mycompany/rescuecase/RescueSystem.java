package com.mycompany.rescuecase;

import java.util.ArrayList;
import java.util.List;

public class RescueSystem {

    // ArrayList stores all rescue cases
    private List<RescueCase> rescueCases;

    // Constructor
    public RescueSystem() {
        rescueCases = new ArrayList<>();
    }

    // Add a new rescue case
    // Returns false if the Case ID already exists
    public boolean addRescueCase(RescueCase rescueCase) {

        if (searchRescueCase(rescueCase.getCaseId()) != null) {
            return false;
        }

        rescueCases.add(rescueCase);
        return true;
    }

    // Search for a rescue case using Case ID
    public RescueCase searchRescueCase(String caseId) {

        for (RescueCase rescueCase : rescueCases) {

            if (rescueCase.getCaseId().equalsIgnoreCase(caseId)) {
                return rescueCase;
            }
        }

        return null;
    }

    // Return all rescue cases
    public List<RescueCase> getRescueCases() {
        return rescueCases;
    }

    // Get total number of rescue cases
    public int getTotalCases() {
        return rescueCases.size();
    }

    // Calculate total estimated rescue cost
    public double getTotalRescueCost() {

        double total = 0;

        for (RescueCase rescueCase : rescueCases) {
            total += rescueCase.calculateTotalCost();
        }

        return total;
    }
}
