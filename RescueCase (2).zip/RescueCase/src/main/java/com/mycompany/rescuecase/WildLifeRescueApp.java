package com.mycompany.rescuecase;

import javax.swing.JOptionPane;

public class WildLifeRescueApp {

    private static RescueSystem system = new RescueSystem();

    public static void main(String[] args) {

        while (true) {

            String option = JOptionPane.showInputDialog(
                    "===== WILDLIFE SA RESCUE SYSTEM =====\n\n"
                    + "1. Create Rescue Case\n"
                    + "2. Search Rescue Case\n"
                    + "3. Update Rescue Status\n"
                    + "4. Start Rescue Operation\n"
                    + "5. Complete Rescue Operation\n"
                    + "6. Display All Rescue Cases\n"
                    + "7. Generate Rescue Report\n"
                    + "8. Exit\n\n"
                    + "Enter your choice:"
            );

            if (option == null) {
                break;
            }

            switch (option.trim()) {

                case "1":
                    createRescueCase();
                    break;

                case "2":
                    searchRescueCase();
                    break;

                case "3":
                    updateStatus();
                    break;

                case "4":
                    startRescue();
                    break;

                case "5":
                    completeRescue();
                    break;

                case "6":
                    displayAllCases();
                    break;

                case "7":
                    generateReport();
                    break;

                case "8":
                    JOptionPane.showMessageDialog(
                            null,
                            "Thank you for using the Wildlife SA Rescue System."
                    );
                    return;

                default:
                    JOptionPane.showMessageDialog(
                            null,
                            "Invalid menu selection. Please enter a number from 1 to 8."
                    );
            }
        }
    }

    // ==========================================
    // CREATE RESCUE CASE
    // ==========================================

    private static void createRescueCase() {

        String type = JOptionPane.showInputDialog(
                "===== SELECT RESCUE TYPE =====\n\n"
                + "1. Injured Animal Rescue\n"
                + "2. Orphaned Animal Rescue\n"
                + "3. Endangered Species Rescue\n\n"
                + "Enter rescue type:"
        );

        if (type == null) {
            return;
        }

        type = type.trim();

        if (!type.equals("1")
                && !type.equals("2")
                && !type.equals("3")) {

            JOptionPane.showMessageDialog(
                    null,
                    "Invalid rescue type."
            );
            return;
        }

        String caseId = getRequiredText(
                "Enter Rescue Case ID:"
        );

        // Check duplicate ID before creating the case
        if (system.searchRescueCase(caseId) != null) {

            JOptionPane.showMessageDialog(
                    null,
                    "A rescue case with ID " + caseId
                    + " already exists.\nPlease use a unique ID."
            );

            return;
        }

        String animalName = getRequiredText(
                "Enter Animal Name:"
        );

        String species = getRequiredText(
                "Enter Species:"
        );

        String rescueLocation = getRequiredText(
                "Enter Rescue Location:"
        );

        String assignedRanger = getRequiredText(
                "Enter Assigned Ranger:"
        );

        int rescueDays = getPositiveInteger(
                "Enter Number of Rescue Days:"
        );

        double dailyCareCost = getPositiveDouble(
                "Enter Daily Care Cost:"
        );

        RescueCase rescueCase;

        // -----------------------------
        // INJURED ANIMAL
        // -----------------------------

        if (type.equals("1")) {

            String injuredDescription = getRequiredText(
                    "Enter Injured Description:"
            );

            double veterinaryTreatmentCost =
                    getPositiveDouble(
                            "Enter Veterinary Treatment Cost:"
                    );

            boolean surgeryRequired =
                    getYesNo(
                            "Is Surgery Required?"
                    );

            rescueCase = new InjuredAnimalRescue(
                    caseId,
                    animalName,
                    species,
                    rescueLocation,
                    assignedRanger,
                    rescueDays,
                    dailyCareCost,
                    injuredDescription,
                    veterinaryTreatmentCost,
                    surgeryRequired
            );
        }

        // -----------------------------
        // ORPHANED ANIMAL
        // -----------------------------

        else if (type.equals("2")) {

            int estimatedAgeMonths =
                    getPositiveInteger(
                            "Enter Estimated Age in Months:"
                    );

            double feedingCost =
                    getPositiveDouble(
                            "Enter Feeding Cost:"
                    );

            boolean fosterCareRequired =
                    getYesNo(
                            "Is Foster Care Required?"
                    );

            rescueCase = new OrphanedAnimalRescue(
                    caseId,
                    animalName,
                    species,
                    rescueLocation,
                    assignedRanger,
                    rescueDays,
                    dailyCareCost,
                    estimatedAgeMonths,
                    feedingCost,
                    fosterCareRequired
            );
        }

        // -----------------------------
        // ENDANGERED SPECIES
        // -----------------------------

        else {

            String classification =
                    getRequiredText(
                            "Enter Conservation Classification:"
                    );

            double securityCost =
                    getPositiveDouble(
                            "Enter Security Cost:"
                    );

            boolean specialTeamRequired =
                    getYesNo(
                            "Is a Special Team Required?"
                    );

            rescueCase = new EndangeredSpeciesRescue(
                    caseId,
                    animalName,
                    species,
                    rescueLocation,
                    assignedRanger,
                    rescueDays,
                    dailyCareCost,
                    classification,
                    securityCost,
                    specialTeamRequired
            );
        }

        if (system.addRescueCase(rescueCase)) {

            JOptionPane.showMessageDialog(
                    null,
                    "Rescue case created successfully!\n\n"
                    + rescueCase.generateRescueSummary()
            );

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "Rescue Case ID already exists."
            );
        }
    }

    // ==========================================
    // SEARCH
    // ==========================================

    private static void searchRescueCase() {

        String id = getRequiredText(
                "Enter Rescue Case ID to search:"
        );

        RescueCase rescueCase =
                system.searchRescueCase(id);

        if (rescueCase == null) {

            JOptionPane.showMessageDialog(
                    null,
                    "Rescue case not found."
            );

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "===== RESCUE CASE =====\n\n"
                    + rescueCase.toString()
            );
        }
    }

    // ==========================================
    // UPDATE STATUS
    // ==========================================

    private static void updateStatus() {

        String id = getRequiredText(
                "Enter Rescue Case ID:"
        );

        RescueCase rescueCase =
                system.searchRescueCase(id);

        if (rescueCase == null) {

            JOptionPane.showMessageDialog(
                    null,
                    "Rescue case not found."
            );

            return;
        }

        String newStatus = getRequiredText(
                "Enter New Rescue Status:"
        );

        rescueCase.setStatus(newStatus);

        JOptionPane.showMessageDialog(
                null,
                "Rescue status updated successfully."
        );
    }

    // ==========================================
    // START RESCUE
    // ==========================================

    private static void startRescue() {

        String id = getRequiredText(
                "Enter Rescue Case ID:"
        );

        RescueCase rescueCase =
                system.searchRescueCase(id);

        if (rescueCase == null) {

            JOptionPane.showMessageDialog(
                    null,
                    "Rescue case not found."
            );

            return;
        }

        rescueCase.startRescue();

        JOptionPane.showMessageDialog(
                null,
                "Rescue operation started.\n\n"
                + "Current Status: "
                + rescueCase.getCurrentRescueStatus()
        );
    }

    // ==========================================
    // COMPLETE RESCUE
    // ==========================================

    private static void completeRescue() {

        String id = getRequiredText(
                "Enter Rescue Case ID:"
        );

        RescueCase rescueCase =
                system.searchRescueCase(id);

        if (rescueCase == null) {

            JOptionPane.showMessageDialog(
                    null,
                    "Rescue case not found."
            );

            return;
        }

        rescueCase.completeRescue();

        JOptionPane.showMessageDialog(
                null,
                "Rescue operation completed.\n\n"
                + "Current Status: "
                + rescueCase.getCurrentRescueStatus()
        );
    }

    // ==========================================
    // DISPLAY ALL CASES
    // ==========================================

    private static void displayAllCases() {

        if (system.getRescueCases().isEmpty()) {

            JOptionPane.showMessageDialog(
                    null,
                    "There are currently no rescue cases."
            );

            return;
        }

        StringBuilder output =
                new StringBuilder(
                        "===== ALL RESCUE CASES =====\n\n"
                );

        for (RescueCase rescueCase :
                system.getRescueCases()) {

            output.append(
                    rescueCase.toString()
            );

            output.append(
                    "\n\n-----------------------------\n\n"
            );
        }

        JOptionPane.showMessageDialog(
                null,
                output.toString()
        );
    }

    // ==========================================
    // REPORT
    // ==========================================

    private static void generateReport() {

        if (system.getRescueCases().isEmpty()) {

            JOptionPane.showMessageDialog(
                    null,
                    "There are no rescue cases to report."
            );

            return;
        }

        StringBuilder report =
                new StringBuilder(
                        "===== WILDLIFE SA RESCUE REPORT =====\n\n"
                );

        for (RescueCase rescueCase :
                system.getRescueCases()) {

            report.append(
                    rescueCase.generateRescueSummary()
            );

            report.append(
                    "\n-----------------------------\n"
            );
        }

        report.append(
                "\nTotal Number of Rescue Cases: "
        );

        report.append(
                system.getTotalCases()
        );

        report.append(
                "\nTotal Estimated Rescue Cost: R"
        );

        report.append(
                String.format(
                        "%.2f",
                        system.getTotalRescueCost()
                )
        );

        JOptionPane.showMessageDialog(
                null,
                report.toString()
        );
    }

    // ==========================================
    // REQUIRED TEXT VALIDATION
    // ==========================================

    private static String getRequiredText(
            String message) {

        while (true) {

            String input =
                    JOptionPane.showInputDialog(
                            message
                    );

            if (input == null) {
                return "";
            }

            if (!input.trim().isEmpty()) {
                return input.trim();
            }

            JOptionPane.showMessageDialog(
                    null,
                    "This field cannot be blank."
            );
        }
    }

    // ==========================================
    // INTEGER VALIDATION
    // ==========================================

    private static int getPositiveInteger(
            String message) {

        while (true) {

            String input =
                    JOptionPane.showInputDialog(
                            message
                    );

            if (input == null) {
                return 1;
            }

            try {

                int value =
                        Integer.parseInt(
                                input.trim()
                        );

                if (value > 0) {
                    return value;
                }

                JOptionPane.showMessageDialog(
                        null,
                        "The value must be greater than zero."
                );

            } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(
                        null,
                        "Please enter a valid whole number."
                );
            }
        }
    }

    // ==========================================
    // DOUBLE VALIDATION
    // ==========================================

    private static double getPositiveDouble(
            String message) {

        while (true) {

            String input =
                    JOptionPane.showInputDialog(
                            message
                    );

            if (input == null) {
                return 1;
            }

            try {

                double value =
                        Double.parseDouble(
                                input.trim()
                        );

                if (value > 0) {
                    return value;
                }

                JOptionPane.showMessageDialog(
                        null,
                        "The value must be greater than zero."
                );

            } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(
                        null,
                        "Please enter a valid number."
                );
            }
        }
    }

    // ==========================================
    // YES / NO
    // ==========================================

    private static boolean getYesNo(
            String message) {

        int answer =
                JOptionPane.showConfirmDialog(
                        null,
                        message,
                        "Confirmation",
                        JOptionPane.YES_NO_OPTION
                );

        return answer == JOptionPane.YES_OPTION;
    }
}

