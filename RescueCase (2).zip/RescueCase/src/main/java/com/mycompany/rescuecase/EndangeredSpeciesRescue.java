package com.mycompany.rescuecase;

public class EndangeredSpeciesRescue extends RescueCase {

    private String conservationClassification;
    private double securityCost;
    private boolean specialTeamRequired;

    public EndangeredSpeciesRescue(
            String caseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int rescueDays,
            double dailyCareCost,
            String conservationClassification,
            double securityCost,
            boolean specialTeamRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialTeamRequired = specialTeamRequired;
    }

    public String getConservationClassification() {
        return conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public boolean isSpecialTeamRequired() {
        return specialTeamRequired;
    }

    @Override
    public double calculateTotalCost() {

        double total = calculateBasicCareCost()
                + securityCost;

        if (specialTeamRequired) {
            total += 8000;
        }

        return total;
    }

    @Override
    public String determinePriority() {

        if (specialTeamRequired) {
            return "HIGH";
        }

        if (securityCost > 0) {
            return "MEDIUM";
        }

        return "LOW";
    }

    @Override
    public String displaySpecificInformation() {

        return "Conservation Classification: "
                + conservationClassification +
                "\nSecurity Cost: R"
                + String.format("%.2f", securityCost) +
                "\nSpecial Team Required: "
                + (specialTeamRequired ? "Yes" : "No");
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }
}