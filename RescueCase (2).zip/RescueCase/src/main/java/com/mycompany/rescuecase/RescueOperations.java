package com.mycompany.rescuecase;

public interface RescueOperations {

    void startRescue();

    void completeRescue();

    String generateRescueSummary();
}