package com.mycompany.rescuecase;

public abstract class RescueCase implements RescueOperations {

    // Common information for every rescue case
    private String caseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int rescueDays;
    private double dailyCareCost;
    private String status;

    // Constructor
    public RescueCase(String caseId, String animalName, String species,
                      String rescueLocation, String assignedRanger,
                      int rescueDays, double dailyCareCost) {

        this.caseId = caseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = "Pending";
    }

    // Getters
    public String getCaseId() {
        return caseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getRescueDays() {
        return rescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public String getCurrentRescueStatus() {
        return status;
    }

    // Setter for status
    public void setStatus(String status) {
        this.status = status;
    }

    // Common daily care cost
    public double calculateBasicCareCost() {
        return rescueDays * dailyCareCost;
    }

    // Methods that each rescue type must implement
    public abstract double calculateTotalCost();

    public abstract String determinePriority();

    public abstract String displaySpecificInformation();

    // Start rescue operation
    @Override
    public void startRescue() {
        status = "In Progress";
    }

    // Complete rescue operation
    @Override
    public void completeRescue() {
        status = "Completed";
    }

    // Common rescue summary
    @Override
    public String generateRescueSummary() {

        return "Rescue Case ID: " + caseId +
                "\nRescue Type: " + getRescueType() +
                "\nSpecies: " + species +
                "\nAssigned Ranger: " + assignedRanger +
                "\nRescue Priority: " + determinePriority() +
                "\nCurrent Status: " + status +
                "\nTotal Rescue Cost: R" +
                String.format("%.2f", calculateTotalCost());
    }

    // Each subclass provides its own rescue type
    public abstract String getRescueType();

    @Override
    public String toString() {

        return generateRescueSummary() +
                "\nAnimal Name: " + animalName +
                "\nRescue Location: " + rescueLocation +
                "\nRescue Days: " + rescueDays +
                "\nDaily Care Cost: R" +
                String.format("%.2f", dailyCareCost) +
                "\n" + displaySpecificInformation();
    }
}

    
    

